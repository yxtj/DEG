Data File Format 
"t # N" means the Nth graph,
"v M L" means that the Mth vertex in this graph has label L,
"e P Q L" means that there is an edge connecting the Pth vertex with the Qth vertex. The edge has label L.

NOTICE: 
1.	All labels cannot be ��0�� or ��1��,  and it should be larger than ��1��;
2.  Each data file or query file should end with �� t # -1��, otherwise it will lead to a bug.
